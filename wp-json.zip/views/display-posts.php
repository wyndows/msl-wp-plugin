

<img src=https://gallery.mailchimp.com/bf1d0f5bebb27fa15f1c84adb/images/78e77fb1-064b-47bf-96ea-43b234357c2c.png height=50 width=50>

<p class="disp_title"><?php echo $_SESSION["title"][ $n - 1 ] ?></p>

<p class="disp_aut_date">by: <?php echo $_SESSION["author"][ $n - 1 ] ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $date ?></p>

<div class="disp_content"><p><?php echo $_SESSION["content"][ $n - 1 ] ?>
-------------------------------------------------------------</p></div>
<br><br><br>

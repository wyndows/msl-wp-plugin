
<p class="disp_category"> <?php echo (do_shortcode( '[create_display]' )) ?> </p>
